# java-maven-quickstart-latest

 this is an up-to-date base archetype for quick starting modern java CLI apps 
